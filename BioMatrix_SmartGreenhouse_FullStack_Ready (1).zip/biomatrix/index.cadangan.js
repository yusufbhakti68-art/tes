// ============================================================================
// BIOMATRIX SMART GREEN HOUSE - INTEGRATED FRONTEND, MQTT & DATABASE ENGINE
// ============================================================================

const DEMO_USERNAME = 'admin';
const DEMO_PASSWORD = 'admin';

// State Global Sensor & Aktuator
let isKipasOn = false;
let isPompaOn = false;
let lastSoilUpdate = 0;
let lastDhtUpdate = 0;
let lastKipasUpdate = 0;
let lastPompaUpdate = 0;
let dbHistoryCache = [];

// Chart Instances
let dashChartInstance = null;
let soilChart = null;
let dhtRealtimeChart = null;
let chartSuhuGrid = null;
let chartUdaraGrid = null;
let chartTanahGrid = null;
let chartAktuatorGrid = null;
let landingDashboardChart = null;

let soilLabels = [];
let soilData = [];

// ============================================================================
// 1. TOAST NOTIFICATION SYSTEM (Modern & Non-Blocking)
// ============================================================================
function showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const colors = {
        success: 'bg-emerald-950/95 border-emerald-500 text-emerald-200',
        error: 'bg-rose-950/95 border-rose-500 text-rose-200',
        info: 'bg-[#082b21]/95 border-[#00e699] text-emerald-100'
    };
    const icons = {
        success: 'fa-circle-check text-[#00e699]',
        error: 'fa-triangle-exclamation text-rose-400',
        info: 'fa-circle-info text-sky-400'
    };

    const toastEl = document.createElement('div');
    toastEl.className = `pointer-events-auto flex items-center gap-3 px-4 py-3 rounded-xl border shadow-xl backdrop-blur-md transition-all duration-300 ${colors[type] || colors.info}`;
    toastEl.innerHTML = `
        <i class="fa-solid ${icons[type] || icons.info} text-base"></i>
        <span class="text-xs font-semibold">${message}</span>
    `;
    container.appendChild(toastEl);

    setTimeout(() => {
        toastEl.style.opacity = '0';
        toastEl.style.transform = 'translateY(10px)';
        setTimeout(() => toastEl.remove(), 300);
    }, 3200);
}

// ============================================================================
// 2. AUTENTIKASI LOGIN (Terintegrasi Database User_tbl + Fallback Offline)
// ============================================================================
function showLoginScreen() {
    document.getElementById('landingPage').style.display = 'none';
    document.getElementById('loginScreen').style.display = 'flex';
}

function showDashboardAfterLogin() {
    document.getElementById('landingPage').style.display = 'none';
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('dashboardApp').style.display = 'flex';
    fetchDatabaseState();
}

async function handleGreenhouseLogin(event) {
    event.preventDefault();
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;

    try {
        const res = await fetch('/api/login.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        if (res.ok && data.ok) {
            sessionStorage.setItem('greenhouseLoggedIn', 'true');
            sessionStorage.setItem('greenhouseUser', data.user?.nama_lengkap || username);
            showDashboardAfterLogin();
            showToast('Login berhasil! Selamat datang di BioMatrix.', 'success');
            return;
        }
    } catch (err) {
        console.warn('Login API fallback ke lokal:', err.message);
    }

    if (username === DEMO_USERNAME && (password === DEMO_PASSWORD || password === 'biomatrix123')) {
        sessionStorage.setItem('greenhouseLoggedIn', 'true');
        showDashboardAfterLogin();
        showToast('Login berhasil!', 'success');
    } else {
        alert('Username atau password salah! Gunakan admin / admin');
    }
}

function togglePassword() {
    const passwordInput = document.getElementById('loginPassword');
    const eyeIcon = document.getElementById('eyeIcon');
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.classList.remove('fa-eye');
        eyeIcon.classList.add('fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        eyeIcon.classList.remove('fa-eye-slash');
        eyeIcon.classList.add('fa-eye');
    }
}

function logoutUser() {
    sessionStorage.removeItem('greenhouseLoggedIn');
    localStorage.removeItem('greenhouseRemembered');
    location.reload();
}

// ============================================================================
// 3. NAVIGASI TAB DASHBOARD (9 Halaman Tanpa Konflik Nama Fungsi)
// ============================================================================
function switchTab(tabId) {
    // Jika dipanggil dengan argumen timeframe landing page ('24h','7d','30d'), arahkan ke fungsi landing chart
    if (['24h', '7d', '30d'].includes(tabId)) {
        switchLandingChartTab(tabId);
        return;
    }

    document.querySelectorAll('.page-content').forEach(el => el.classList.add('hidden'));
    const activePage = document.getElementById(`page-${tabId}`);
    if (activePage) activePage.classList.remove('hidden');

    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('bg-[#0e4334]', 'text-white', 'glow-green');
        btn.classList.add('text-emerald-200/70');
    });

    const activeBtn = document.querySelector(`.nav-btn[data-tab="${tabId}"]`);
    if (activeBtn) {
        activeBtn.classList.add('bg-[#0e4334]', 'text-white', 'glow-green');
        activeBtn.classList.remove('text-emerald-200/70');
    }

    if (window.innerWidth < 1024) {
        const sb = document.getElementById('sidebar');
        if (sb) sb.classList.add('hidden');
    }
}

// ============================================================================
// 4. SINKRONISASI DATABASE MARIADB (/api/state.php, /api/settings.php, dll)
// ============================================================================
async function fetchDatabaseState() {
    try {
        const res = await fetch('/api/state.php', { cache: 'no-store' });
        if (!res.ok) return;
        const data = await res.json();
        if (!data.ok) return;

        // 1. Update nilai sensor terbaru dari DB jika MQTT belum mengirim paket baru
        if (data.latest && lastSoilUpdate === 0 && lastDhtUpdate === 0) {
            const s = parseFloat(data.latest.suhu);
            const h = parseFloat(data.latest.kelembapan_udara);
            const t = parseFloat(data.latest.kelembapan_tanah);
            if (!isNaN(t)) applySoilToDOM(t, data.latest.waktu_pencatatan);
            if (!isNaN(s) && !isNaN(h)) applyDhtToDOM(s, h, data.latest.waktu_pencatatan);
        }

        // 2. Update status aktuator dari DB
        if (data.actuators) {
            if (data.actuators.kipas && lastKipasUpdate === 0) {
                isKipasOn = data.actuators.kipas.status_aktuator === 'ON';
                updateKipasUI(isKipasOn);
            }
            if (data.actuators.pompa && lastPompaUpdate === 0) {
                isPompaOn = data.actuators.pompa.status_aktuator === 'ON';
                updatePompaUI(isPompaOn);
            }
        }

        // 3. Isi Tabel Riwayat Data (Page 8) & Grafik dari Database
        if (Array.isArray(data.history) && data.history.length > 0) {
            dbHistoryCache = data.history;
            renderHistoryTable(data.history);
            populateChartsFromHistory(data.history);
        }

        // 4. Isi Form Pengaturan (Page 9) dari Database
        if (data.device) {
            const elNama = document.getElementById('setting-nama-perangkat');
            const elMode = document.getElementById('setting-mode-sistem');
            if (elNama && document.activeElement !== elNama) elNama.value = data.device.nama_perangkat;
            if (elMode && document.activeElement !== elMode) elMode.value = data.device.mode_sistem;
        }
        if (data.settings) {
            const elSuhu = document.getElementById('setting-suhu-maks');
            const elUdara = document.getElementById('setting-udara-min');
            const elTanah = document.getElementById('setting-tanah-min');
            if (elSuhu && document.activeElement !== elSuhu) elSuhu.value = parseFloat(data.settings.suhu_maks);
            if (elUdara && document.activeElement !== elUdara) elUdara.value = parseFloat(data.settings.kelembapan_udara_min);
            if (elTanah && document.activeElement !== elTanah) elTanah.value = parseFloat(data.settings.kelembapan_tanah_min);
        }
    } catch (e) {
        console.warn('Sinkronisasi DB belum tersedia:', e.message);
    }
}

function renderHistoryTable(historyList) {
    const tbody = document.getElementById('riwayat-table-body');
    if (!tbody) return;

    tbody.innerHTML = historyList.map((row, idx) => {
        const kipasBadge = row.status_kipas === 'ON'
            ? '<span class="bg-emerald-950 text-[#00e699] border border-emerald-700 px-2.5 py-0.5 rounded text-[10px] font-semibold">Aktif</span>'
            : '<span class="bg-slate-800 text-slate-300 px-2.5 py-0.5 rounded text-[10px]">Mati</span>';
        const pompaBadge = row.status_pompa === 'ON'
            ? '<span class="bg-sky-950 text-sky-300 border border-sky-700 px-2.5 py-0.5 rounded text-[10px] font-semibold">Aktif</span>'
            : '<span class="bg-slate-800 text-slate-300 px-2.5 py-0.5 rounded text-[10px]">Mati</span>';

        return `
            <tr class="hover:bg-[#082b21]/60 transition">
                <td class="p-3">${idx + 1}</td>
                <td class="p-3 font-mono text-emerald-300">${row.waktu_format}</td>
                <td class="p-3 font-semibold text-white">${ parseFloat(row.suhu).toFixed(1) } °C</td>
                <td class="p-3 font-semibold text-white">${ parseFloat(row.kelembapan_udara).toFixed(0) }%</td>
                <td class="p-3 font-semibold text-white">${ parseFloat(row.kelembapan_tanah).toFixed(0) }%</td>
                <td class="p-3">${kipasBadge}</td>
                <td class="p-3">${pompaBadge}</td>
            </tr>
        `;
    }).join('');
}

function populateChartsFromHistory(historyList) {
    const chronological = [...historyList].reverse().slice(-15);
    const labels = chronological.map(r => r.jam_format);
    const suhuArr = chronological.map(r => parseFloat(r.suhu));
    const udaraArr = chronological.map(r => parseFloat(r.kelembapan_udara));
    const tanahArr = chronological.map(r => parseFloat(r.kelembapan_tanah));

    if (dashChartInstance) {
        dashChartInstance.data.labels = labels;
        dashChartInstance.data.datasets[0].data = tanahArr;
        dashChartInstance.data.datasets[1].data = suhuArr;
        dashChartInstance.data.datasets[2].data = udaraArr;
        dashChartInstance.update('none');
    }

    if (soilChart && soilLabels.length === 0) {
        soilLabels.push(...labels);
        soilData.push(...tanahArr);
        soilChart.update('none');
    }

    if (dhtRealtimeChart && dhtRealtimeChart.data.labels.length === 0) {
        dhtRealtimeChart.data.labels = [...labels];
        dhtRealtimeChart.data.datasets[0].data = [...suhuArr];
        dhtRealtimeChart.data.datasets[1].data = [...udaraArr];
        dhtRealtimeChart.update('none');
    }

    if (chartSuhuGrid) {
        chartSuhuGrid.data.labels = labels;
        chartSuhuGrid.data.datasets[0].data = suhuArr;
        chartSuhuGrid.update('none');
    }
    if (chartUdaraGrid) {
        chartUdaraGrid.data.labels = labels;
        chartUdaraGrid.data.datasets[0].data = udaraArr;
        chartUdaraGrid.update('none');
    }
    if (chartTanahGrid) {
        chartTanahGrid.data.labels = labels;
        chartTanahGrid.data.datasets[0].data = tanahArr;
        chartTanahGrid.update('none');
    }
}

async function saveGreenhouseSettings() {
    const payload = {
        nama_perangkat: document.getElementById('setting-nama-perangkat')?.value || 'BioMatrix Greenhouse',
        mode_sistem: document.getElementById('setting-mode-sistem')?.value || 'Otomatis',
        suhu_maks: parseFloat(document.getElementById('setting-suhu-maks')?.value || 30),
        kelembapan_udara_min: parseFloat(document.getElementById('setting-udara-min')?.value || 50),
        kelembapan_tanah_min: parseFloat(document.getElementById('setting-tanah-min')?.value || 50)
    };

    try {
        const res = await fetch('/api/settings.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await res.json();
        if (data.ok) {
            showToast('Pengaturan berhasil disimpan ke Database MariaDB!', 'success');
            return;
        }
    } catch (e) {
        console.warn('Gagal simpan ke DB:', e.message);
    }
    showToast('Pengaturan disimpan', 'success');
}

// ============================================================================
// 5. KONEKSI REAL-TIME MQTT WEBSOCKET (Otomatis Mengikuti IP Server / Proxy)
// ============================================================================
const wsHost = window.location.hostname || '10.15.42.1';
const MQTT_BROKER = `ws://${wsHost}:9001`;
console.log('Menghubungkan ke MQTT Broker:', MQTT_BROKER);

const mqttClient = mqtt.connect(MQTT_BROKER, {
    reconnectPeriod: 3000,
    connectTimeout: 10000,
    clean: true
});

function setMqttBadge(online) {
    const badge = document.getElementById('mqtt-status-badge');
    const dot = document.getElementById('mqtt-status-dot');
    const txt = document.getElementById('mqtt-status-text');
    if (!badge || !dot || !txt) return;

    if (online) {
        badge.className = 'flex items-center gap-2 px-3 py-1.5 rounded-lg border border-emerald-500/40 bg-emerald-950/60 text-emerald-300 text-xs font-semibold';
        dot.className = 'w-2 h-2 rounded-full bg-[#00e699] animate-ping';
        txt.textContent = 'ESP32 & MQTT Online';
    } else {
        badge.className = 'flex items-center gap-2 px-3 py-1.5 rounded-lg border border-amber-500/40 bg-amber-950/60 text-amber-300 text-xs font-semibold';
        dot.className = 'w-2 h-2 rounded-full bg-amber-400';
        txt.textContent = 'Menunggu Sinyal MQTT...';
    }
}

mqttClient.on('connect', function () {
    console.log('MQTT DASHBOARD TERHUBUNG:', MQTT_BROKER);
    setMqttBadge(true);
    mqttClient.subscribe('biomatrix/sensor/tanah');
    mqttClient.subscribe('biomatrix/sensor/dht11');
    mqttClient.subscribe('biomatrix/kipas');
    mqttClient.subscribe('biomatrix/pompa');
});

mqttClient.on('offline', () => setMqttBadge(false));
mqttClient.on('error', (err) => console.warn('MQTT Warning:', err.message));

function formatTanggalUpdate() {
    const sekarang = new Date();
    return sekarang.toLocaleString('id-ID', {
        day: '2-digit', month: '2-digit', year: 'numeric',
        hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
    });
}

function applySoilToDOM(soil, waktuStr) {
    const dashboardSoil = document.getElementById('dashboard-soil');
    if (dashboardSoil) dashboardSoil.innerHTML = `${soil}<span class="text-sm font-normal text-emerald-300">%</span>`;

    const soilProgress = document.getElementById('dashboard-soil-progress');
    if (soilProgress) soilProgress.innerText = `${soil}%`;

    const soilBar = document.getElementById('soil-progress-bar');
    if (soilBar) soilBar.style.width = `${Math.min(100, Math.max(0, soil))}%`;

    const sensorSoil = document.getElementById('sensor-soil');
    if (sensorSoil) sensorSoil.innerText = `${soil}%`;

    const tanahValue = document.getElementById('tanah-value');
    if (tanahValue) tanahValue.innerText = `${soil}%`;

    const tanahInfo = document.getElementById('tanah-info-value');
    if (tanahInfo) tanahInfo.innerText = `${soil}%`;

    const heroSoil = document.getElementById('hero-soil');
    if (heroSoil) heroSoil.innerText = `${soil}%`;

    const dashSoil = document.getElementById('dash-soil');
    if (dashSoil) dashSoil.innerText = `${soil}%`;

    const tanahLastUpdate = document.getElementById('tanah-last-update');
    if (tanahLastUpdate && waktuStr) tanahLastUpdate.innerText = waktuStr;
}

function applyDhtToDOM(suhu, kelembapan, waktuStr) {
    const dashboardTemperature = document.getElementById('dashboard-temperature');
    if (dashboardTemperature) dashboardTemperature.innerHTML = `${suhu}<span class="text-sm font-normal text-emerald-300">°C</span>`;

    const dashboardHumidity = document.getElementById('dashboard-humidity');
    if (dashboardHumidity) dashboardHumidity.innerHTML = `${kelembapan}<span class="text-sm font-normal text-emerald-300">%</span>`;

    const temperatureText = document.getElementById('temperature-progress-text');
    if (temperatureText) temperatureText.innerText = `${suhu} °C`;

    const tempBar = document.getElementById('temperature-progress-bar');
    if (tempBar) tempBar.style.width = `${Math.min(100, Math.max(0, (suhu / 50) * 100))}%`;

    const humidityText = document.getElementById('humidity-progress-text');
    if (humidityText) humidityText.innerText = `${kelembapan}%`;

    const humidityBar = document.getElementById('humidity-progress-bar');
    if (humidityBar) humidityBar.style.width = `${Math.min(100, Math.max(0, kelembapan))}%`;

    const sensorTemperature = document.getElementById('sensor-temperature');
    if (sensorTemperature) sensorTemperature.innerText = `${suhu} °C`;

    const sensorHumidity = document.getElementById('sensor-humidity');
    if (sensorHumidity) sensorHumidity.innerText = `${kelembapan}%`;

    const dhtTemperature = document.getElementById('dht-temperature');
    if (dhtTemperature) dhtTemperature.innerText = `${suhu} °C`;

    const dhtHumidity = document.getElementById('dht-humidity');
    if (dhtHumidity) dhtHumidity.innerText = `${kelembapan}%`;

    const heroTemp = document.getElementById('hero-temp');
    if (heroTemp) heroTemp.innerText = `${suhu}°C`;

    const heroHum = document.getElementById('hero-hum');
    if (heroHum) heroHum.innerText = `${kelembapan}%`;

    const dashTemp = document.getElementById('dash-temp');
    if (dashTemp) dashTemp.innerText = `${suhu}°C`;

    const dashHum = document.getElementById('dash-hum');
    if (dashHum) dashHum.innerText = `${kelembapan}%`;

    if (waktuStr) {
        document.querySelectorAll('.realtime-last-update').forEach(el => { el.innerText = waktuStr; });
    }
}

mqttClient.on('message', function (topic, message) {
    const data = message.toString().trim();
    const waktuSekarang = formatTanggalUpdate();

    if (topic === 'biomatrix/sensor/tanah') {
        const soil = parseFloat(data);
        if (isNaN(soil)) {
            updateActivityLog('Kelembapan Tanah', '--', 'Error Sensor');
            return;
        }
        lastSoilUpdate = Date.now();
        updateActivityLog('Kelembapan Tanah', `${soil}%`, 'Normal');
        applySoilToDOM(soil, waktuSekarang);
        updateSoilChart(soil);
    }

    if (topic === 'biomatrix/sensor/dht11') {
        try {
            const dht = JSON.parse(data);
            const suhu = parseFloat(dht.suhu);
            const kelembapan = parseFloat(dht.kelembapan);
            if (isNaN(suhu) || isNaN(kelembapan)) {
                updateActivityLog('DHT11 (Suhu)', '--', 'Error Sensor');
                updateActivityLog('DHT11 (Kelembapan)', '--', 'Error Sensor');
                return;
            }
            lastDhtUpdate = Date.now();
            updateActivityLog('DHT11 (Suhu)', `${suhu} °C`, 'Normal');
            updateActivityLog('DHT11 (Kelembapan)', `${kelembapan}%`, 'Normal');
            applyDhtToDOM(suhu, kelembapan, waktuSekarang);
            updateDHTChart(suhu, kelembapan);
        } catch (err) {
            console.error('Format JSON DHT11 tidak valid:', data);
        }
    }

    if (topic === 'biomatrix/kipas') {
        const status = data.toUpperCase();
        if (status === 'ON' || status === 'OFF') {
            isKipasOn = (status === 'ON');
            lastKipasUpdate = Date.now();
            updateKipasUI(isKipasOn);
            updateActivityLog('Kipas', status, 'Normal');
        }
    }

    if (topic === 'biomatrix/pompa') {
        const status = data.toUpperCase();
        if (status === 'ON' || status === 'OFF') {
            isPompaOn = (status === 'ON');
            lastPompaUpdate = Date.now();
            updatePompaUI(isPompaOn);
            updateActivityLog('Pompa', status, 'Normal');
        }
    }
});

// ============================================================================
// 6. PERBARUI TABEL LOG AKTIVITAS TERBARU (4 Kolom di Dashboard)
// ============================================================================
function updateActivityLog(device, value, description) {
    const headings = document.querySelectorAll('h3');
    let table = null;
    headings.forEach(function (heading) {
        if (heading.innerText.trim() === 'Log Aktivitas Terbaru') {
            table = heading.parentElement.querySelector('table');
        }
    });
    if (!table) return;

    const rows = table.querySelectorAll('tbody tr');
    rows.forEach(function (row) {
        const cells = row.querySelectorAll('td');
        // Tabel di HTML memiliki 4 kolom: 0=Waktu, 1=Sensor/Aktuator, 2=Nilai/Status, 3=Keterangan
        if (cells.length < 4) return;

        const idxDevice = cells.length === 4 ? 1 : 2;
        const idxTime   = cells.length === 4 ? 0 : 1;
        const idxVal    = cells.length === 4 ? 2 : 3;
        const idxDesc   = cells.length === 4 ? 3 : 4;

        if (cells[idxDevice].innerText.trim() !== device) return;

        const now = new Date();
        cells[idxTime].innerText =
            now.getHours().toString().padStart(2, '0') + ':' +
            now.getMinutes().toString().padStart(2, '0') + ':' +
            now.getSeconds().toString().padStart(2, '0');
        cells[idxVal].innerText = value;

        if (description === 'Normal') {
            cells[idxDesc].innerHTML = '<span class="bg-emerald-950 text-emerald-300 px-2 py-0.5 rounded text-[10px] border border-emerald-800">Normal</span>';
        } else {
            cells[idxDesc].innerHTML = `<span class="bg-red-950 text-red-300 px-2 py-0.5 rounded text-[10px] border border-red-800">${description}</span>`;
        }
    });
}

// ============================================================================
// 7. UPDATE UI KIPAS & POMPA (Menangani Dashboard Gelap & Demo Landing Page)
// ============================================================================
function updateKipasUI(state) {
    document.querySelectorAll('.toggle-kipas-input').forEach(input => { input.checked = state; });
    document.querySelectorAll('.label-kipas-text').forEach(text => { text.innerText = state ? 'Aktif (Menyala)' : 'Mati'; });
    document.querySelectorAll('.card-kipas-text').forEach(text => { text.innerText = state ? 'Aktif' : 'Mati'; });
    document.querySelectorAll('.card-kipas-badge').forEach(badge => {
        badge.innerText = state ? 'Aktif' : 'Nonaktif';
        badge.className = state
            ? 'text-[10px] bg-emerald-950 text-[#00e699] px-2 py-0.5 rounded border border-emerald-700 card-kipas-badge'
            : 'text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700 card-kipas-badge';
    });

    document.querySelectorAll('.icon-kipas-box').forEach(box => {
        const icon = box.querySelector('i');
        if (icon) {
            icon.classList.toggle('animate-spin', state);
            icon.classList.toggle('text-[#00e699]', state);
            icon.classList.toggle('text-slate-400', !state);
        }
    });
}

function updatePompaUI(state) {
    document.querySelectorAll('.toggle-pompa-input').forEach(input => { input.checked = state; });
    document.querySelectorAll('.label-pompa-text').forEach(text => { text.innerText = state ? 'Aktif (Menyala)' : 'Mati'; });
    document.querySelectorAll('.card-pompa-text').forEach(text => { text.innerText = state ? 'Aktif' : 'Mati'; });
    document.querySelectorAll('.card-pompa-badge').forEach(badge => {
        badge.innerText = state ? 'Aktif' : 'Nonaktif';
        badge.className = state
            ? 'text-[10px] bg-sky-950 text-sky-300 px-2 py-0.5 rounded border border-sky-700 card-pompa-badge'
            : 'text-[10px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded border border-slate-700 card-pompa-badge';
    });

    document.querySelectorAll('.icon-pompa-box').forEach(box => {
        const icon = box.querySelector('i');
        if (icon) {
            icon.classList.toggle('animate-bounce', state);
            icon.classList.toggle('text-blue-400', state);
            icon.classList.toggle('text-slate-400', !state);
        }
    });
}

// ============================================================================
// 8. KONTROL AKTUATOR (Kirim ke MQTT ESP32 + Simpan ke Database MariaDB)
// ============================================================================
async function toggleActuator(type, state) {
    const command = state ? 'ON' : 'OFF';

    // 1. Publish ke MQTT jika terhubung
    if (mqttClient && mqttClient.connected) {
        const topic = type === 'kipas' ? 'biomatrix/kipas/control' : 'biomatrix/pompa/control';
        mqttClient.publish(topic, command);
    }

    // 2. Simpan perubahan status ke Database MariaDB via API
    try {
        await fetch('/api/actuator.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ aktuator: type, status: command })
        });
    } catch (e) {
        console.warn('API Actuator fallback:', e.message);
    }

    if (type === 'kipas') {
        isKipasOn = state;
        updateKipasUI(state);
        updateActivityLog('Kipas', command, 'Normal');
        showToast(`Kipas ${state ? 'Dinyalakan' : 'Dimatikan'}`, 'success');
    } else if (type === 'pompa') {
        isPompaOn = state;
        updatePompaUI(state);
        updateActivityLog('Pompa', command, 'Normal');
        showToast(`Pompa ${state ? 'Dinyalakan' : 'Dimatikan'}`, 'success');
    }
}

// ============================================================================
// 9. EXPORT RIWAYAT DATA KE CSV (Mengambil Data Asli dari Database)
// ============================================================================
function exportToCSV() {
    const header = ["No", "Waktu", "Suhu (C)", "Kelembapan Udara (%)", "Kelembapan Tanah (%)", "Kipas", "Pompa"];
    const sourceRows = dbHistoryCache.length > 0
        ? dbHistoryCache.map((r, i) => [
            i + 1,
            r.waktu_format,
            r.suhu,
            r.kelembapan_udara,
            r.kelembapan_tanah,
            r.status_kipas === 'ON' ? 'Aktif' : 'Mati',
            r.status_pompa === 'ON' ? 'Aktif' : 'Mati'
        ])
        : [
            ["1", formatTanggalUpdate(), "28.5", "72", "65", isKipasOn ? "Aktif" : "Mati", isPompaOn ? "Aktif" : "Mati"]
        ];

    const rows = [header, ...sourceRows];
    const csvContent = "data:text/csv;charset=utf-8," + rows.map(e => e.join(",")).join("\n");
    const link = document.createElement("a");
    link.setAttribute("href", encodeURI(csvContent));
    link.setAttribute("download", "riwayat_sensor_biomatrix.csv");
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('File CSV riwayat database berhasil diunduh!', 'success');
}

// ============================================================================
// 10. UPDATE GRAFIK REAL-TIME
// ============================================================================
function updateSoilChart(value) {
    const now = new Date();
    const time = now.toTimeString().slice(0, 8);
    soilLabels.push(time);
    soilData.push(value);
    if (soilLabels.length > 20) {
        soilLabels.shift();
        soilData.shift();
    }
    if (soilChart) soilChart.update();
}

function updateDHTChart(temperature, humidity) {
    const now = new Date();
    const time = now.toTimeString().slice(0, 8);
    if (dhtRealtimeChart) {
        dhtRealtimeChart.data.labels.push(time);
        dhtRealtimeChart.data.datasets[0].data.push(temperature);
        dhtRealtimeChart.data.datasets[1].data.push(humidity);
        if (dhtRealtimeChart.data.labels.length > 20) {
            dhtRealtimeChart.data.labels.shift();
            dhtRealtimeChart.data.datasets[0].data.shift();
            dhtRealtimeChart.data.datasets[1].data.shift();
        }
        dhtRealtimeChart.update();
    }
}

// ============================================================================
// 11. SIMULASI INTERAKTIF & LANDING PAGE HANDLERS
// ============================================================================
function updateSimulation() {
    const suhuEl = document.getElementById('input-suhu');
    const udaraEl = document.getElementById('input-udara');
    const tanahEl = document.getElementById('input-tanah');
    if (!suhuEl || !udaraEl || !tanahEl) return;

    const suhuVal = parseFloat(suhuEl.value);
    const udaraVal = parseInt(udaraEl.value);
    const tanahVal = parseInt(tanahEl.value);

    document.getElementById('val-suhu').textContent = suhuVal.toFixed(1) + '°C';
    document.getElementById('slider-val-suhu').textContent = suhuVal.toFixed(1) + '°C';
    document.getElementById('val-udara').textContent = udaraVal + '%';
    document.getElementById('slider-val-udara').textContent = udaraVal + '%';
    document.getElementById('val-tanah').textContent = tanahVal + '%';
    document.getElementById('slider-val-tanah').textContent = tanahVal + '%';

    const simKipasON = suhuVal > 30.0;
    const toggleKipasSim = document.getElementById('toggle-kipas');
    if (toggleKipasSim) toggleKipasSim.checked = simKipasON;
    updateDemoKipasCard(simKipasON);

    const simPompaON = tanahVal < 50;
    const togglePompaSim = document.getElementById('toggle-pompa');
    if (togglePompaSim) togglePompaSim.checked = simPompaON;
    updateDemoPompaCard(simPompaON, tanahVal);
}

function updateDemoKipasCard(isON) {
    const badgeSuhu = document.getElementById('badge-suhu');
    const simBadgeSuhu = document.getElementById('sim-badge-suhu');
    const sidebarIcon = document.getElementById('sidebar-icon-kipas');
    const sidebarLabel = document.getElementById('sidebar-label-kipas');
    const statusCardKipas = document.getElementById('status-card-kipas');
    const infoKipasStatus = document.getElementById('info-kipas-status');
    const ruleHigh = document.getElementById('rule-suhu-high');
    const ruleLow = document.getElementById('rule-suhu-low');
    if (!badgeSuhu) return;

    if (isON) {
        badgeSuhu.innerHTML = `<span class="bg-orange-100 text-orange-600 text-[11px] font-bold px-2.5 py-0.5 rounded-full inline-flex items-center gap-1">▲ > 30°C (Kipas ON)</span>`;
        simBadgeSuhu.innerHTML = `<span class="bg-emerald-100 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded-full">&gt; 30°C (Kipas ON)</span>`;
        sidebarIcon?.classList.add('fan-spin');
        if (sidebarLabel) { sidebarLabel.textContent = 'ON'; sidebarLabel.className = 'text-xs font-bold text-emerald-800'; }
        if (statusCardKipas) statusCardKipas.className = 'p-4 rounded-xl border border-gray-100 bg-[#F2FAF5] flex items-center justify-between transition-all';
        if (infoKipasStatus) infoKipasStatus.textContent = 'Kipas ON pada > 30°C';
        if (ruleHigh) { ruleHigh.textContent = 'Aktif'; ruleHigh.className = 'text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700'; }
        if (ruleLow) { ruleLow.textContent = 'Tidak Aktif'; ruleLow.className = 'text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-gray-100 text-gray-500'; }
    } else {
        badgeSuhu.innerHTML = `<span class="bg-gray-100 text-gray-600 text-[11px] font-bold px-2.5 py-0.5 rounded-full inline-flex items-center gap-1">✓ Normal (≤ 30°C)</span>`;
        simBadgeSuhu.innerHTML = `<span class="bg-gray-100 text-gray-600 text-[10px] font-bold px-2 py-0.5 rounded-full">≤ 30°C (Kipas OFF)</span>`;
        sidebarIcon?.classList.remove('fan-spin');
        if (sidebarLabel) { sidebarLabel.textContent = 'OFF'; sidebarLabel.className = 'text-xs font-bold text-gray-400'; }
        if (statusCardKipas) statusCardKipas.className = 'p-4 rounded-xl border border-gray-100 bg-gray-50 opacity-80 flex items-center justify-between transition-all';
        if (infoKipasStatus) infoKipasStatus.textContent = 'Kipas OFF pada ≤ 30°C';
        if (ruleHigh) { ruleHigh.textContent = 'Tidak Aktif'; ruleHigh.className = 'text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-gray-100 text-gray-500'; }
        if (ruleLow) { ruleLow.textContent = 'Aktif'; ruleLow.className = 'text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700'; }
    }
}

function updateDemoPompaCard(isON, val) {
    const badgeTanah = document.getElementById('badge-tanah');
    const simBadgeTanah = document.getElementById('sim-badge-tanah');
    const sidebarLabel = document.getElementById('sidebar-label-pompa');
    const statusCardPompa = document.getElementById('status-card-pompa');
    const infoPompaStatus = document.getElementById('info-pompa-status');
    const ruleLow = document.getElementById('rule-tanah-low');
    const ruleHigh = document.getElementById('rule-tanah-high');
    if (!badgeTanah) return;

    if (isON) {
        badgeTanah.innerHTML = `<span class="bg-sky-100 text-sky-700 text-[11px] font-bold px-2.5 py-0.5 rounded-full inline-flex items-center gap-1">💧 < 50% (Pompa ON)</span>`;
        simBadgeTanah.innerHTML = `<span class="bg-sky-100 text-sky-700 text-[10px] font-bold px-2 py-0.5 rounded-full">&lt; 50% (Pompa ON)</span>`;
        if (sidebarLabel) { sidebarLabel.textContent = 'ON'; sidebarLabel.className = 'text-xs font-bold text-sky-800'; }
        if (statusCardPompa) statusCardPompa.className = 'p-4 rounded-xl border border-gray-100 bg-[#F0F9FF] flex items-center justify-between transition-all';
        if (infoPompaStatus) infoPompaStatus.textContent = 'Pompa ON pada < 50%';
        if (ruleLow) { ruleLow.textContent = 'Aktif'; ruleLow.className = 'text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700'; }
        if (ruleHigh) { ruleHigh.textContent = 'Tidak Aktif'; ruleHigh.className = 'text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-gray-100 text-gray-500'; }
    } else {
        badgeTanah.innerHTML = val >= 70
            ? `<span class="bg-emerald-100 text-emerald-700 text-[11px] font-bold px-2.5 py-0.5 rounded-full inline-flex items-center gap-1">✓ Tanah Basah (≥ 70%)</span>`
            : `<span class="bg-gray-100 text-gray-600 text-[11px] font-bold px-2.5 py-0.5 rounded-full inline-flex items-center gap-1">✓ Normal (50%-69%)</span>`;
        simBadgeTanah.innerHTML = `<span class="bg-emerald-100 text-emerald-700 text-[10px] font-bold px-2 py-0.5 rounded-full">Pompa OFF</span>`;
        if (sidebarLabel) { sidebarLabel.textContent = 'OFF'; sidebarLabel.className = 'text-xs font-bold text-gray-400'; }
        if (statusCardPompa) statusCardPompa.className = 'p-4 rounded-xl border border-gray-100 bg-gray-50 opacity-80 flex items-center justify-between transition-all';
        if (infoPompaStatus) infoPompaStatus.textContent = 'Pompa OFF pada ≥ 50%';
        if (ruleLow) { ruleLow.textContent = 'Tidak Aktif'; ruleLow.className = 'text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-gray-100 text-gray-500'; }
        if (ruleHigh) { ruleHigh.textContent = 'Aktif'; ruleHigh.className = 'text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700'; }
    }
}

function manualToggle(device, isChecked) {
    if (device === 'kipas') {
        const suhuInput = document.getElementById('input-suhu');
        if (suhuInput) suhuInput.value = isChecked ? 32.5 : 28.0;
    } else if (device === 'pompa') {
        const tanahInput = document.getElementById('input-tanah');
        if (tanahInput) tanahInput.value = isChecked ? 42 : 72;
    }
    updateSimulation();
}

let actuatorState = { fan: true, pump: false };
function toggleSwitch(device) {
    actuatorState[device] = !actuatorState[device];
    if (device === 'fan') {
        toggleActuator('kipas', actuatorState.fan);
        const btn = document.getElementById('fan-toggle-btn');
        const icon = document.getElementById('fan-icon');
        const bg = document.getElementById('fan-bg');
        if (btn && icon && bg) {
            if (actuatorState.fan) {
                btn.className = "px-3 py-1 rounded-full text-[10px] font-bold bg-emerald-600 text-white flex items-center gap-1";
                btn.innerHTML = '<span>ON</span><span class="w-2 h-2 rounded-full bg-white"></span>';
                icon.classList.add('animate-spin');
                bg.className = "w-9 h-9 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center text-base";
            } else {
                btn.className = "px-3 py-1 rounded-full text-[10px] font-bold bg-gray-300 text-gray-700 flex items-center gap-1";
                btn.innerHTML = '<span>OFF</span><span class="w-2 h-2 rounded-full bg-gray-500"></span>';
                icon.classList.remove('animate-spin');
                bg.className = "w-9 h-9 rounded-xl bg-gray-100 text-gray-400 flex items-center justify-center text-base";
            }
        }
    } else if (device === 'pump') {
        toggleActuator('pompa', actuatorState.pump);
        const btn = document.getElementById('pump-toggle-btn');
        const bg = document.getElementById('pump-bg');
        if (btn && bg) {
            if (actuatorState.pump) {
                btn.className = "px-3 py-1 rounded-full text-[10px] font-bold bg-emerald-600 text-white flex items-center gap-1";
                btn.innerHTML = '<span>ON</span><span class="w-2 h-2 rounded-full bg-white"></span>';
                bg.className = "w-9 h-9 rounded-xl bg-sky-100 text-sky-600 flex items-center justify-center text-base";
            } else {
                btn.className = "px-3 py-1 rounded-full text-[10px] font-bold bg-gray-300 text-gray-700 flex items-center gap-1";
                btn.innerHTML = '<span>OFF</span><span class="w-2 h-2 rounded-full bg-gray-500"></span>';
                bg.className = "w-9 h-9 rounded-xl bg-gray-100 text-gray-400 flex items-center justify-center text-base";
            }
        }
    }
}

const chartDataSets = {
    '24h': { labels: ['00:00', '06:00', '12:00', '18:00', '24:00'], soil: [65, 68, 62, 67, 68], temp: [24, 25, 32, 28, 27.4], hum: [82, 80, 65, 75, 78] },
    '7d':  { labels: ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'], soil: [60, 64, 68, 70, 66, 68, 68], temp: [26, 27, 28, 29, 27, 27, 27.4], hum: [75, 76, 78, 80, 77, 78, 78] },
    '30d': { labels: ['M1', 'M2', 'M3', 'M4'], soil: [62, 65, 67, 68], temp: [26.5, 27.0, 27.2, 27.4], hum: [76, 77, 79, 78] }
};

function switchLandingChartTab(timeframe) {
    if (!landingDashboardChart || !chartDataSets[timeframe]) return;
    ['24h', '7d', '30d'].forEach(t => {
        const btn = document.getElementById(`tab-${t}`);
        if (btn) {
            btn.className = (t === timeframe)
                ? "px-2.5 py-1 rounded-md bg-bm-dark text-white"
                : "px-2.5 py-1 rounded-md bg-white text-gray-600 border border-gray-200";
        }
    });
    landingDashboardChart.data.labels = chartDataSets[timeframe].labels;
    landingDashboardChart.data.datasets[0].data = chartDataSets[timeframe].soil;
    landingDashboardChart.data.datasets[1].data = chartDataSets[timeframe].temp;
    landingDashboardChart.data.datasets[2].data = chartDataSets[timeframe].hum;
    landingDashboardChart.update();
}

async function handleFormSubmit(e) {
    e.preventDefault();
    const nama = document.getElementById('contact-nama')?.value || '';
    const email = document.getElementById('contact-email')?.value || '';
    const pesan = document.getElementById('contact-pesan')?.value || '';

    try {
        await fetch('/api/contact.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nama, email, pesan })
        });
    } catch (err) {
        console.warn('Form disimpan lokal:', err.message);
    }

    const feedback = document.getElementById('form-feedback');
    if (feedback) {
        feedback.classList.remove('hidden');
        setTimeout(() => feedback.classList.add('hidden'), 5000);
    }
    document.getElementById('contact-form')?.reset();
}

// ============================================================================
// 12. INISIALISASI TUNGGAL SAAT HALAMAN DIMUAT (Semua Grafik & Timer Jalan!)
// ============================================================================
function updateTanggalWaktu() {
    const sekarang = new Date();
    const tanggal = sekarang.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
    const waktu = sekarang.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
    const elemen = document.getElementById('current-datetime');
    if (elemen) elemen.textContent = `${tanggal}, ${waktu} WIB`;
}

document.addEventListener('DOMContentLoaded', function () {
    // 1. Cek Status Login
    if (sessionStorage.getItem('greenhouseLoggedIn') === 'true') {
        showDashboardAfterLogin();
    } else {
        document.getElementById('landingPage').style.display = 'block';
        document.getElementById('loginScreen').style.display = 'none';
        document.getElementById('dashboardApp').style.display = 'none';
    }

    // 2. Toggle Menu Mobile
    document.getElementById('menu-toggle')?.addEventListener('click', () => {
        document.getElementById('sidebar')?.classList.toggle('hidden');
    });
    document.getElementById('mobile-menu-btn')?.addEventListener('click', () => {
        document.getElementById('mobile-menu')?.classList.toggle('hidden');
    });

    // 3. Inisialisasi Semua Chart.js (Landing Page + Dashboard Utama + Tanah + DHT11 + 4 Grid)
    const ctxLanding = document.getElementById('dashboardChart')?.getContext('2d');
    if (ctxLanding) {
        landingDashboardChart = new Chart(ctxLanding, {
            type: 'line',
            data: {
                labels: chartDataSets['24h'].labels,
                datasets: [
                    { label: 'Soil Moisture', data: chartDataSets['24h'].soil, borderColor: '#10b981', borderWidth: 2, tension: 0.4, pointRadius: 3 },
                    { label: 'Temperature', data: chartDataSets['24h'].temp, borderColor: '#fb923c', borderWidth: 2, tension: 0.4, pointRadius: 3 },
                    { label: 'Humidity', data: chartDataSets['24h'].hum, borderColor: '#0ea5e9', borderWidth: 2, tension: 0.4, pointRadius: 3 }
                ]
            },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
        });
    }

    const ctxDash = document.getElementById('dashChart')?.getContext('2d');
    if (ctxDash) {
        dashChartInstance = new Chart(ctxDash, {
            type: 'line',
            data: {
                labels: ['07:00', '07:10', '07:20', '07:30', '07:40'],
                datasets: [
                    { label: 'Kelembapan Tanah (%)', data: [62, 60, 64, 63, 65], borderColor: '#10b981', tension: 0.3 },
                    { label: 'Suhu (°C)', data: [27.8, 28.0, 28.2, 28.4, 28.5], borderColor: '#f59e0b', tension: 0.3 },
                    { label: 'Kelembapan Udara (%)', data: [75, 73, 71, 70, 72], borderColor: '#3b82f6', tension: 0.3 }
                ]
            },
            options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }
        });
    }

    const ctxTanah = document.getElementById('tanahChart')?.getContext('2d');
    if (ctxTanah) {
        soilChart = new Chart(ctxTanah, {
            type: 'line',
            data: {
                labels: soilLabels,
                datasets: [{
                    label: 'Kelembapan Tanah (%)',
                    data: soilData,
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16,185,129,0.12)',
                    fill: true,
                    tension: 0.3
                }]
            },
            options: { responsive: true, maintainAspectRatio: false, scales: { y: { min: 0, max: 100 } } }
        });
    }

    const ctxDHT = document.getElementById('dhtChart')?.getContext('2d');
    if (ctxDHT) {
        dhtRealtimeChart = new Chart(ctxDHT, {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    { label: 'Suhu (°C)', data: [], borderColor: '#f59e0b', tension: 0.3 },
                    { label: 'Kelembapan Udara (%)', data: [], borderColor: '#3b82f6', tension: 0.3 }
                ]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    const optGrid = { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } };
    if (document.getElementById('chartSuhu')) {
        chartSuhuGrid = new Chart(document.getElementById('chartSuhu'), { type: 'line', data: { labels: ['1', '2', '3', '4'], datasets: [{ data: [27, 28, 28.5, 28], borderColor: '#f59e0b', tension: 0.3 }] }, options: optGrid });
    }
    if (document.getElementById('chartUdara')) {
        chartUdaraGrid = new Chart(document.getElementById('chartUdara'), { type: 'line', data: { labels: ['1', '2', '3', '4'], datasets: [{ data: [70, 72, 71, 72], borderColor: '#3b82f6', tension: 0.3 }] }, options: optGrid });
    }
    if (document.getElementById('chartTanah2')) {
        chartTanahGrid = new Chart(document.getElementById('chartTanah2'), { type: 'line', data: { labels: ['1', '2', '3', '4'], datasets: [{ data: [62, 64, 63, 65], borderColor: '#10b981', tension: 0.3 }] }, options: optGrid });
    }
    if (document.getElementById('chartAktuator')) {
        chartAktuatorGrid = new Chart(document.getElementById('chartAktuator'), { type: 'bar', data: { labels: ['07:00', '07:10', '07:20', '07:30'], datasets: [{ label: 'Kipas', data: [0, 1, 0, 0], backgroundColor: '#10b981' }, { label: 'Pompa', data: [1, 0, 0, 0], backgroundColor: '#3b82f6' }] }, options: optGrid });
    }

    // 4. Jalankan Jam, Simulasi, dan Polling Database Setiap 5 Detik
    updateTanggalWaktu();
    setInterval(updateTanggalWaktu, 1000);
    updateSimulation();
    fetchDatabaseState();
    setInterval(fetchDatabaseState, 5000);
});
