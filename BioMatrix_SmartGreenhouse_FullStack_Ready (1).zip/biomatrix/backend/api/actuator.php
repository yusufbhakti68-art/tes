<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

try {
    require __DIR__ . '/../config/database.php';
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $kode = strtolower(trim((string)($input['aktuator'] ?? '')));
    $status = strtoupper(trim((string)($input['status'] ?? 'OFF')));

    if (!in_array($kode, ['kipas', 'pompa']) || !in_array($status, ['ON', 'OFF'])) {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Parameter aktuator tidak valid']);
        exit;
    }

    $pdo->prepare("UPDATE Aktuator_tbl SET status_aktuator = ?, terakhir_diubah = NOW() WHERE kode_aktuator = ?")
        ->execute([$status, $kode]);

    $komponen = $kode === 'kipas' ? 'Kipas' : 'Pompa';
    $pdo->prepare("INSERT INTO Log_aktivitas_tbl (komponen, nilai_status, keterangan) VALUES (?, ?, 'Normal')")
        ->execute([$komponen, $status]);

    echo json_encode(['ok' => true, 'aktuator' => $kode, 'status' => $status]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
