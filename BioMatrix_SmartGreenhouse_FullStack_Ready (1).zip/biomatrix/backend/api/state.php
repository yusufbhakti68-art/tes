<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

try {
    require __DIR__ . '/../config/database.php';

    $device = $pdo->query("SELECT * FROM Perangkat_tbl ORDER BY id_perangkat LIMIT 1")->fetch();
    $settings = $pdo->query("SELECT * FROM Pengaturan_tbl ORDER BY id_pengaturan LIMIT 1")->fetch();
    $actuators = $pdo->query("SELECT kode_aktuator, nama_aktuator, status_aktuator, mode_kontrol, terakhir_diubah FROM Aktuator_tbl")->fetchAll();
    $latestLog = $pdo->query("SELECT * FROM Log_sensor_tbl ORDER BY id_log DESC LIMIT 1")->fetch();
    $history = $pdo->query("SELECT id_log, suhu, kelembapan_udara, kelembapan_tanah, status_kipas, status_pompa, keterangan, DATE_FORMAT(waktu_pencatatan, '%d-%m-%Y %H:%i:%s') AS waktu_format, DATE_FORMAT(waktu_pencatatan, '%H:%i:%s') AS jam_format FROM Log_sensor_tbl ORDER BY id_log DESC LIMIT 30")->fetchAll();

    $aktMap = [];
    foreach ($actuators as $a) {
        $aktMap[$a['kode_aktuator']] = $a;
    }

    echo json_encode([
        'ok' => true,
        'device' => $device,
        'settings' => $settings,
        'actuators' => $aktMap,
        'latest' => $latestLog,
        'history' => $history,
        'server_time' => date('Y-m-d H:i:s')
    ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
