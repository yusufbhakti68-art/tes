<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

try {
    require __DIR__ . '/../config/database.php';
    $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
    $nama = trim((string)($input['nama'] ?? ''));
    $email = trim((string)($input['email'] ?? ''));
    $pesan = trim((string)($input['pesan'] ?? ''));

    if ($nama === '' || $email === '' || $pesan === '') {
        http_response_code(400);
        echo json_encode(['ok' => false, 'error' => 'Semua kolom wajib diisi']);
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO Pesan_kontak_tbl (nama_lengkap, email, isi_pesan) VALUES (?, ?, ?)");
    $stmt->execute([$nama, $email, $pesan]);

    echo json_encode(['ok' => true, 'message' => 'Pesan konsultasi berhasil disimpan ke database']);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
