<?php
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');

try {
    require __DIR__ . '/../config/database.php';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $namaPerangkat = trim((string)($input['nama_perangkat'] ?? 'BioMatrix Greenhouse'));
        $modeSistem = in_array($input['mode_sistem'] ?? '', ['Otomatis', 'Manual']) ? $input['mode_sistem'] : 'Otomatis';
        $intervalUpdate = trim((string)($input['interval_update'] ?? '5 Detik'));
        $suhuMaks = (float)($input['suhu_maks'] ?? 30.0);
        $udaraMin = (float)($input['kelembapan_udara_min'] ?? 50.0);
        $tanahMin = (float)($input['kelembapan_tanah_min'] ?? 50.0);

        $pdo->prepare("UPDATE Perangkat_tbl SET nama_perangkat = ?, mode_sistem = ?, interval_update = ? WHERE id_perangkat = 1")
            ->execute([$namaPerangkat, $modeSistem, $intervalUpdate]);

        $pdo->prepare("UPDATE Pengaturan_tbl SET suhu_maks = ?, kelembapan_udara_min = ?, kelembapan_tanah_min = ? WHERE id_perangkat = 1")
            ->execute([$suhuMaks, $udaraMin, $tanahMin]);

        echo json_encode(['ok' => true, 'message' => 'Pengaturan berhasil disimpan ke database']);
        exit;
    }

    $device = $pdo->query("SELECT * FROM Perangkat_tbl WHERE id_perangkat = 1")->fetch();
    $settings = $pdo->query("SELECT * FROM Pengaturan_tbl WHERE id_perangkat = 1")->fetch();
    echo json_encode(['ok' => true, 'device' => $device, 'settings' => $settings]);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
