#!/usr/bin/env python3
import os
import json
import time
import pymysql
import paho.mqtt.client as mqtt

DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
DB_PORT = int(os.getenv("DB_PORT", "3306"))
DB_NAME = os.getenv("DB_NAME", "biomatrix")
DB_USER = os.getenv("DB_USER", "biomatrix")
DB_PASS = os.getenv("DB_PASS", "biomatrix123")

MQTT_HOST = os.getenv("MQTT_HOST", "127.0.0.1")
MQTT_PORT = int(os.getenv("MQTT_PORT", "1883"))
MQTT_USER = os.getenv("MQTT_USER", "biomatrix")
MQTT_PASS = os.getenv("MQTT_PASS", "biomatrix123")

state = {
    "suhu": 28.5,
    "kelembapan_udara": 72.0,
    "kelembapan_tanah": 65.0,
    "kipas": "OFF",
    "pompa": "OFF",
    "last_db_insert": 0
}

def get_db():
    return pymysql.connect(
        host=DB_HOST,
        port=DB_PORT,
        user=DB_USER,
        password=DB_PASS,
        database=DB_NAME,
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=True
    )

def save_snapshot(force=False):
    now = time.time()
    # Simpan ke Log_sensor_tbl maksimal setiap 5 detik atau saat aktuator berubah
    if not force and (now - state["last_db_insert"] < 5):
        return
    state["last_db_insert"] = now
    try:
        conn = get_db()
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE Perangkat_tbl SET status_koneksi='online', last_seen=NOW() WHERE id_perangkat=1"
            )
            cur.execute(
                """INSERT INTO Log_sensor_tbl
                   (id_perangkat, suhu, kelembapan_udara, kelembapan_tanah, status_kipas, status_pompa, keterangan)
                   VALUES (1, %s, %s, %s, %s, %s, 'Normal')""",
                (state["suhu"], state["kelembapan_udara"], state["kelembapan_tanah"], state["kipas"], state["pompa"])
            )
        conn.close()
    except Exception as e:
        print(f"[DB ERROR] {e}", flush=True)

def update_actuator_db(kode, status):
    try:
        conn = get_db()
        with conn.cursor() as cur:
            cur.execute(
                "UPDATE Aktuator_tbl SET status_aktuator=%s, terakhir_diubah=NOW() WHERE kode_aktuator=%s",
                (status, kode)
            )
            nama = "Kipas" if kode == "kipas" else "Pompa"
            cur.execute(
                "INSERT INTO Log_aktivitas_tbl (komponen, nilai_status, keterangan) VALUES (%s, %s, 'Normal')",
                (nama, status)
            )
        conn.close()
    except Exception as e:
        print(f"[DB ACTUATOR ERROR] {e}", flush=True)

def on_connect(client, userdata, flags, rc):
    print(f"[MQTT WORKER] Terhubung ke broker dengan kode: {rc}", flush=True)
    client.subscribe("biomatrix/sensor/tanah")
    client.subscribe("biomatrix/sensor/dht11")
    client.subscribe("biomatrix/kipas")
    client.subscribe("biomatrix/pompa")
    client.subscribe("biomatrix/kipas/control")
    client.subscribe("biomatrix/pompa/control")

def on_message(client, userdata, msg):
    topic = msg.topic
    payload = msg.payload.decode("utf-8", errors="ignore").strip()
    print(f"[MQTT IN] {topic} -> {payload}", flush=True)

    try:
        if topic == "biomatrix/sensor/tanah":
            val = float(payload)
            state["kelembapan_tanah"] = val
            save_snapshot(force=False)

        elif topic == "biomatrix/sensor/dht11":
            data = json.loads(payload)
            state["suhu"] = float(data.get("suhu", state["suhu"]))
            state["kelembapan_udara"] = float(data.get("kelembapan", state["kelembapan_udara"]))
            save_snapshot(force=False)

        elif topic in ("biomatrix/kipas", "biomatrix/kipas/control"):
            st = "ON" if payload.upper() == "ON" else "OFF"
            if state["kipas"] != st:
                state["kipas"] = st
                update_actuator_db("kipas", st)
                save_snapshot(force=True)

        elif topic in ("biomatrix/pompa", "biomatrix/pompa/control"):
            st = "ON" if payload.upper() == "ON" else "OFF"
            if state["pompa"] != st:
                state["pompa"] = st
                update_actuator_db("pompa", st)
                save_snapshot(force=True)

    except Exception as e:
        print(f"[PARSE ERROR] {topic}: {e}", flush=True)

def main():
    client = mqtt.Client()
    if MQTT_USER:
        client.username_pw_set(MQTT_USER, MQTT_PASS)
    client.on_connect = on_connect
    client.on_message = on_message

    while True:
        try:
            client.connect(MQTT_HOST, MQTT_PORT, 60)
            client.loop_forever()
        except Exception as e:
            print(f"[MQTT RETRY] {e}, mencoba lagi dalam 3 detik...", flush=True)
            time.sleep(3)

if __name__ == "__main__":
    main()
