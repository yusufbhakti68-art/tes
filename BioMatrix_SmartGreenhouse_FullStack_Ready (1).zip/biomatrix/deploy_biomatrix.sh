#!/bin/bash
set -e

echo "=================================================================="
echo "  AUTO-DEPLOY BIOMATRIX SMART GREEN HOUSE (Nginx + MariaDB + MQTT)"
echo "=================================================================="

# 1. Pastikan paket terinstal
apt update
apt install -y nginx mariadb-server mosquitto mosquitto-clients php-fpm php-mysql php-cli python3-venv python3-pip

# 2. Siapkan direktori /var/www/biomatrix
mkdir -p /var/www/biomatrix
cp -r ./* /var/www/biomatrix/
chown -R www-data:www-data /var/www/biomatrix

# 3. Setup Database MariaDB & Import biomatrix.sql
systemctl enable --now mariadb
mysql -u root << 'EOF'
CREATE DATABASE IF NOT EXISTS biomatrix CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER IF NOT EXISTS 'biomatrix'@'localhost' IDENTIFIED BY 'biomatrix123';
CREATE USER IF NOT EXISTS 'biomatrix'@'127.0.0.1' IDENTIFIED BY 'biomatrix123';
CREATE USER IF NOT EXISTS 'biomatrix'@'%' IDENTIFIED BY 'biomatrix123';
GRANT ALL PRIVILEGES ON biomatrix.* TO 'biomatrix'@'localhost';
GRANT ALL PRIVILEGES ON biomatrix.* TO 'biomatrix'@'127.0.0.1';
GRANT ALL PRIVILEGES ON biomatrix.* TO 'biomatrix'@'%';
FLUSH PRIVILEGES;
EOF

mysql -u biomatrix -pbiomatrix123 biomatrix < /var/www/biomatrix/database/biomatrix.sql

# 4. Konfigurasi Mosquitto MQTT (Port 1883 untuk ESP32 & Port 9001 untuk WebSocket Dashboard)
cat << 'EOF' > /etc/mosquitto/conf.d/biomatrix.conf
allow_anonymous true
listener 1883 0.0.0.0
protocol mqtt

listener 9001 0.0.0.0
protocol websockets
EOF
systemctl enable --now mosquitto
systemctl restart mosquitto

# 5. Setup Python MQTT Worker Service (Mencatat data ESP32 otomatis ke MariaDB)
python3 -m venv /var/www/biomatrix/backend/mqtt/venv
/var/www/biomatrix/backend/mqtt/venv/bin/pip install paho-mqtt pymysql cryptography

cat << 'EOF' > /etc/systemd/system/biomatrix-mqtt.service
[Unit]
Description=BioMatrix Smart Greenhouse MQTT to MariaDB Worker
After=network.target mosquitto.service mariadb.service

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/biomatrix/backend/mqtt
Environment="DB_HOST=127.0.0.1"
Environment="DB_NAME=biomatrix"
Environment="DB_USER=biomatrix"
Environment="DB_PASS=biomatrix123"
Environment="MQTT_HOST=127.0.0.1"
Environment="MQTT_PORT=1883"
ExecStart=/var/www/biomatrix/backend/mqtt/venv/bin/python /var/www/biomatrix/backend/mqtt/worker.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now biomatrix-mqtt.service
systemctl restart biomatrix-mqtt.service

# 6. Deteksi socket PHP-FPM otomatis & Setup VirtualHost Nginx (Port 8080 agar bisa berdampingan dengan SmartParking atau Port 80)
PHP_SOCK=$(find /run/php/ -name "php*-fpm.sock" | head -n 1)

cat << EOF > /etc/nginx/sites-available/biomatrix.conf
server {
    listen 8080 default_server;
    server_name _;

    root /var/www/biomatrix;
    index index.html index.php;

    location / {
        try_files \$uri \$uri/ /index.html;
    }

    location ^~ /api/ {
        rewrite ^/api/(.*)$ /backend/api/\$1 last;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:$PHP_SOCK;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
    }

    location /mqtt {
        proxy_pass http://127.0.0.1:9001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "Upgrade";
        proxy_set_header Host \$host;
    }
}
EOF

ln -sf /etc/nginx/sites-available/biomatrix.conf /etc/nginx/sites-enabled/biomatrix.conf
nginx -t && systemctl reload nginx

SERVER_IP=$(hostname -I | awk '{print $1}')
echo "=================================================================="
echo " DEPLOY BIOMATRIX SELESAI 100%!"
echo " Akses Web Dashboard : http://$SERVER_IP:8080"
echo " Login Default       : admin / admin"
echo " Broker MQTT ESP32   : $SERVER_IP (Port 1883)"
echo " WebSocket MQTT      : ws://$SERVER_IP:9001"
echo "=================================================================="
