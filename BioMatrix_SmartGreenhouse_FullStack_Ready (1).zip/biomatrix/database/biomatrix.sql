-- ============================================================================
-- DATABASE SCHEMA: BIOMATRIX SMART GREEN HOUSE (MariaDB / MySQL Compatible)
-- ============================================================================
DROP DATABASE IF EXISTS biomatrix;
CREATE DATABASE biomatrix CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE biomatrix;

-- 1. Tabel Pengguna (Admin & Operator)
CREATE TABLE User_tbl (
    id_user BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    nama_lengkap VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'operator') NOT NULL DEFAULT 'admin',
    last_login DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. Tabel Perangkat IoT (ESP32 Node)
CREATE TABLE Perangkat_tbl (
    id_perangkat BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode_perangkat VARCHAR(50) NOT NULL UNIQUE,
    nama_perangkat VARCHAR(100) NOT NULL,
    versi_firmware VARCHAR(30) NOT NULL DEFAULT 'v1.2.0',
    mode_sistem ENUM('Otomatis', 'Manual') NOT NULL DEFAULT 'Otomatis',
    interval_update VARCHAR(30) NOT NULL DEFAULT '5 Detik',
    status_koneksi ENUM('online', 'offline') NOT NULL DEFAULT 'online',
    ip_address VARCHAR(45) NULL,
    last_seen DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. Tabel Pengaturan Ambang Batas Otomatis (Threshold)
CREATE TABLE Pengaturan_tbl (
    id_pengaturan BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_perangkat BIGINT UNSIGNED NOT NULL,
    suhu_maks DECIMAL(5,2) NOT NULL DEFAULT 30.00,
    kelembapan_udara_min DECIMAL(5,2) NOT NULL DEFAULT 50.00,
    kelembapan_tanah_min DECIMAL(5,2) NOT NULL DEFAULT 50.00,
    kelembapan_tanah_maks DECIMAL(5,2) NOT NULL DEFAULT 70.00,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_pengaturan_perangkat FOREIGN KEY (id_perangkat) REFERENCES Perangkat_tbl(id_perangkat) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 4. Tabel Status Aktuator Saat Ini (Kipas & Pompa)
CREATE TABLE Aktuator_tbl (
    id_aktuator BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    kode_aktuator VARCHAR(30) NOT NULL UNIQUE,
    nama_aktuator VARCHAR(50) NOT NULL,
    status_aktuator ENUM('ON', 'OFF') NOT NULL DEFAULT 'OFF',
    mode_kontrol ENUM('Otomatis', 'Manual') NOT NULL DEFAULT 'Otomatis',
    terakhir_diubah DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 5. Tabel Riwayat Pembacaan Sensor Terpadu (Untuk Tabel Riwayat, Grafik & Export CSV)
CREATE TABLE Log_sensor_tbl (
    id_log BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    id_perangkat BIGINT UNSIGNED NOT NULL DEFAULT 1,
    suhu DECIMAL(5,2) NOT NULL,
    kelembapan_udara DECIMAL(5,2) NOT NULL,
    kelembapan_tanah DECIMAL(5,2) NOT NULL,
    status_kipas ENUM('ON', 'OFF') NOT NULL DEFAULT 'OFF',
    status_pompa ENUM('ON', 'OFF') NOT NULL DEFAULT 'OFF',
    keterangan VARCHAR(50) NOT NULL DEFAULT 'Normal',
    waktu_pencatatan DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_waktu (waktu_pencatatan),
    CONSTRAINT fk_log_perangkat FOREIGN KEY (id_perangkat) REFERENCES Perangkat_tbl(id_perangkat) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 6. Tabel Log Aktivitas Real-Time Per Sensor/Aktuator
CREATE TABLE Log_aktivitas_tbl (
    id_aktivitas BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    komponen VARCHAR(60) NOT NULL,
    nilai_status VARCHAR(40) NOT NULL,
    keterangan VARCHAR(60) NOT NULL DEFAULT 'Normal',
    waktu DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_komponen_waktu (komponen, waktu)
) ENGINE=InnoDB;

-- 7. Tabel Pesan Konsultasi / Kontak Landing Page
CREATE TABLE Pesan_kontak_tbl (
    id_pesan BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nama_lengkap VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    isi_pesan TEXT NOT NULL,
    status_baca ENUM('belum_dibaca', 'sudah_dibaca') NOT NULL DEFAULT 'belum_dibaca',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================================
-- DATA AWAL (SEEDER)
-- ============================================================================
-- Password default 'admin' & 'biomatrix123' (di-handle juga oleh API login)
INSERT INTO User_tbl (username, nama_lengkap, email, password_hash, role) VALUES
('admin', 'Yusuf Administrator', 'yusuf@biomatrix.id', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

INSERT INTO Perangkat_tbl (id_perangkat, kode_perangkat, nama_perangkat, versi_firmware, mode_sistem, interval_update, status_koneksi) VALUES
(1, 'BG-001', 'BioMatrix Greenhouse', 'v1.2.0', 'Otomatis', '5 Detik', 'online');

INSERT INTO Pengaturan_tbl (id_perangkat, suhu_maks, kelembapan_udara_min, kelembapan_tanah_min, kelembapan_tanah_maks) VALUES
(1, 30.00, 50.00, 50.00, 70.00);

INSERT INTO Aktuator_tbl (kode_aktuator, nama_aktuator, status_aktuator, mode_kontrol) VALUES
('kipas', 'Kipas Sirkulasi Greenhouse', 'OFF', 'Otomatis'),
('pompa', 'Pompa Irigasi Tetes', 'OFF', 'Otomatis');

INSERT INTO Log_sensor_tbl (id_perangkat, suhu, kelembapan_udara, kelembapan_tanah, status_kipas, status_pompa, keterangan, waktu_pencatatan) VALUES
(1, 27.9, 68.0, 62.0, 'OFF', 'OFF', 'Normal', DATE_SUB(NOW(), INTERVAL 20 MINUTE)),
(1, 28.2, 70.0, 63.0, 'OFF', 'OFF', 'Normal', DATE_SUB(NOW(), INTERVAL 15 MINUTE)),
(1, 28.4, 71.0, 64.0, 'OFF', 'OFF', 'Normal', DATE_SUB(NOW(), INTERVAL 10 MINUTE)),
(1, 28.5, 72.0, 65.0, 'OFF', 'OFF', 'Normal', DATE_SUB(NOW(), INTERVAL 5 MINUTE));

INSERT INTO Log_aktivitas_tbl (komponen, nilai_status, keterangan) VALUES
('DHT11 (Suhu)', '28.5 °C', 'Normal'),
('DHT11 (Kelembapan)', '72%', 'Normal'),
('Kelembapan Tanah', '65%', 'Normal'),
('Pompa', 'OFF', 'Normal'),
('Kipas', 'OFF', 'Normal');
